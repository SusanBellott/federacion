<script setup>
import { Link } from '@inertiajs/vue3';
</script>

<template>
    <Link :href="'/'">
        <img 
            src="/assets/img/logo_instituto.png" 
            alt="Logo del Instituto"
            style="height: 200px; width: auto;"
        >
    </Link>
</template>